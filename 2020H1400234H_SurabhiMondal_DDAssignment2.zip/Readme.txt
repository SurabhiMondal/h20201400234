Task is to:
Write a kernel module to create a DiskonFile block device called “dof” which is basically a user space file (/etc/sample.txt) being presented as a block device to the system.
The kernel module should write procedures to read from and write to this user space file whenever there is any read write request from the kernel to block device dof. 
This block device should have 2 primary partitions (/dev/dof1 & /dev/dof2) and no extended partitions.
Fill up the MBR details in the appropriate sector.
Block device size should be 512 KB with sector size of 512 bytes.

Clearly two partitions has been created using struct PartEntry Tables, and setting the blkdev.gd->minors=2.
The block device has been named dof using register_blkdev(major_num, "dof");

MBR details has been filled up.

The read and write procedures has been implemented using request_xfer, which both reads and writes to user space by analying the rq_data_dir(req) in the struct request.